import logo from "./logo.svg";
import "./App.css";
import Slider from "./component/Slider";

function App() {
  return (
    <div>
      <Slider />
    </div>
  );
}

export default App;
